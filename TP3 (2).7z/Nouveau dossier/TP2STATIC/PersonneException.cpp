/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PersonneException.cpp
 * Author: etudiant
 * 
 * Created on 7 décembre 2023, 20 h 38
 */

#include "PersonneException.h"

PersonneException::PersonneException (const std::string& raison):std::runtime_error(raison) { }
PersonneDejaPresenteException::PersonneDejaPresenteException (const std::string& raison):PersonneException (raison){}
PersonneAbsenteException::PersonneAbsenteException(const std::string& raison): PersonneException (raison){}


