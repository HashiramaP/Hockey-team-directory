/*
 * \file Personnetesteur.cpp
 * \brief teste l'implementation de la classe Entraineur
 * \param[in] string p_nom
 * \param[in] string prenom
 * \param[in] Date de naissance
 * \param[in] string p_telephone
 * \param[in] string position
*/
#include <stdlib.h>
#include <iostream>
#include<gtest/gtest.h>
#include"Personne.h"
#include"Date.h"
#include"ContratException.h"
#include<cstring>
#include<iostream>
class Personne1:public hockey::Personne{
  public:
    Personne1 (const std::string &p_nom,const std::string &p_prenom,
            const util::Date &p_dateNaissance,
            const std::string &p_telephone):Personne(p_nom,p_prenom,p_dateNaissance,p_telephone){}
    virtual std::unique_ptr<hockey::Personne> clone ()const override {
      return std::make_unique<Personne1>(*this);
    }
    virtual std::string reqPersonneFormate (){
      return hockey::Personne::reqPersonneFormate ();
    }
};

/*
 * \brief test unitaire pour le constructeur avec des attributs 
           les cas non valide :nom ou prenon qui sont vide ou des telephone incomplet
 */

TEST(Personne1,constructeur){
  util::Date t;
  Personne1 Briton("Briton","Muvunyi",t,"418-543-6789");
  ASSERT_EQ("418-543-6789",Briton.reqtelephone ());
  ASSERT_EQ("Briton",Briton.reqnom ());
  ASSERT_EQ("Muvunyi",Briton.reqprenom ());
  ASSERT_EQ(t,Briton.reqdateNaissance ());
}
TEST(Personne1,constructeurInvalidnom){
  util::Date t;
  ASSERT_THROW(Personne1 Briton("123","Muvunyi",t,"418-543-6789"),ContratException);
}
TEST(Personne,constructeurInvalidprenom){
  util::Date t;
  ASSERT_THROW(Personne1 Briton("Briton","123",t,"418-543-6789"),ContratException);
}
TEST(Personne1,constructeurInvalidtel){
  util::Date t;
  ASSERT_THROW(Personne1 Briton("Briton","Muvunyi",t,"418-543-"),ContratException);
}
class unePersonne : public ::testing::Test
{

public:
  util::Date t;
  unePersonne():f_Briton("Briton","Muvunyi",t,"418-543-6789"){};
  Personne1 f_Briton;
}; 
/*
 * \brief test unitaire pour le fonction asgtelephone()
          cas non-valide:format invalide de telephone 
 */
TEST_F(unePersonne,reqtelephone){
 
  ASSERT_EQ("418-543-6789",f_Briton.reqtelephone ());
}
/**
 * \brief test unitaire pour le fonction reqnom
          cas invalide:le variable p_nom est different du le retour de la fonction
 */
TEST_F(unePersonne,reqnom){
 ASSERT_EQ("Briton",f_Briton.reqnom ());
}
/**
 * \brief test unitaire pour le fonction reqprenom
          cas invalide:le variable p_prenom est different du le retour de la fonction
 */
TEST_F(unePersonne,reqprenom){
  
  ASSERT_EQ("Muvunyi",f_Briton.reqprenom ());
}
/**
 * \brief test unitaire pour le fonction asgtelephone
          cas invalide:le variable p_telephone est different du le retour de la fonction
 */
TEST_F(unePersonne,asgtelephone){
  f_Briton.asgtelephone("418-543-6789");
  ASSERT_EQ("418-543-6789",f_Briton.reqtelephone ());
}
/**
 * \brief test unitaire pour le fonction reqdatedenaissance
          cas invalide:le variable p_datedenaissance est different du le retour de la fonction
 */
TEST_F(unePersonne,reqdateNaissance){
  util::Date y;
  ASSERT_EQ(y.reqDateFormatee (),f_Briton.reqdateNaissance ().reqDateFormatee ());
}
/**
 * \brief test unitaire pour le fonction reqPersonneFormate ()
          cas invalide:le string on veut sortir est different du retour de la fonction
 */
TEST_F(unePersonne,reqPersonneFormate){
  std::ostringstream os;
  os<<"Nom                :"<<f_Briton.reqnom ()<<"\n"<<"Prenom             :";
  os <<f_Briton.reqprenom ()<<"\n"<<"Date de Naissance  :";
  os <<f_Briton.reqdateNaissance().reqDateFormatee ()<<"\n";
  os <<"Telephone          :"<<f_Briton.reqtelephone ();
  
  ASSERT_EQ(os.str(),f_Briton.reqPersonneFormate ());
}
/**
 * \brief test unitaire pour le fonction surchagee de la fonction ==
          cas invalide:aucun
 */
TEST_F(unePersonne,surchageergale){
  util::Date t;
  Personne1 Briton("Briton","Muvunyi",t,"418-543-6789");
  ASSERT_EQ(Briton,f_Briton);
}
/**
 * \brief test unitaire pour le fonction asgtelephone
          cas invalide:le variable p_telephone est different du le retour de la fonction
 */
TEST_F(unePersonne,asgtelephoneInvalide){
  ASSERT_THROW(f_Briton.asgtelephone("18-543-6789"),ContratException);
}