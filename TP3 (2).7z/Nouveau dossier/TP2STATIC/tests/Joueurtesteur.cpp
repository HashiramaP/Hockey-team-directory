/**
 * \file Joueurtesteur.cpp
 * \brief teste l'implemntation de la classe Joueur
 * \param[in] string p_nom
 * \param[in] string prenom
 * \param[in] Date de naissance
 * \param[in] string p_telephone
 * \param[in] string p_position 
 */
#include <stdlib.h>
#include <iostream>
#include"Joueur.h"
#include<gtest/gtest.h>
#include"Date.h"
#include"ContratException.h"
#include<cstring>
#include<iostream>
/**
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas valide :age du joueur doit etre entre 15 et 19
 *   cas valide :position ailier ou centre ou defenseur ou gardien
 */
TEST(Joueur,Constructeur){
  util::Date t(1,1,2006);
  hockey::Joueur Briton("BONNEAU","JEAN",t,"514-369-9874","ailier");
  ASSERT_EQ("BONNEAU",Briton.reqnom ());
  ASSERT_EQ("JEAN",Briton.reqprenom ());
  ASSERT_EQ(t,Briton.reqdateNaissance ());
  ASSERT_EQ("514-369-9874",Briton.reqtelephone ());
  ASSERT_EQ("ailier",Briton.reqposition());
}
/**
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :age du joueur n'est pas  etre entre 15 et 19
 */
TEST(Joueur,ConstructeurInvaliddatedenaisance){
  ASSERT_THROW(hockey::Joueur Briton("BONNEAU","JEAN",util::Date(1,1,2002),"514-369-9874","centre"),ContratException);
}
/**
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :position mn'est pas ailier ou centre ou defenseur ou gardien
 */
TEST(Joueur,ConstructeurInvalidposition){
  ASSERT_THROW(hockey::Joueur Briton("BONNEAU","JEAN",util::Date(1,1,2002),"514-369-9874","tre"),ContratException);
}
class JoueurValid:public ::testing::Test
{
public :
  JoueurValid() :f_Briton("BONNEAU","JEAN",util::Date (1,1,2007),"514-369-9874","centre"){};
  hockey::Joueur f_Briton;
};
/**
 *\brief test de la  fonction qui retourne la position 
 * CAS VALIDE :retour est ceux que on veut
 */
TEST_F(JoueurValid,reqposition){
  ASSERT_EQ("centre",f_Briton.reqposition());
}
/**
 *\brief test de la  fonction qui retourne la chaine avec tout les attributs  
 * CAS VALIDE :retour est ceux que on veut
 */
TEST_F(JoueurValid,reqPersonneFormate)
{
  std::ostringstream os;
  os<<"Nom                :"<<f_Briton.reqnom()<<"\n"<<"Prenom             :"
          <<f_Briton.reqprenom()<<"\n"
          <<"Date de Naissance  :"<<f_Briton.reqdateNaissance().reqDateFormatee ()<<"\n"
          <<"Telephone          :"<<f_Briton.reqtelephone ()<<"\n"
          <<"Position           :"<<f_Briton.reqposition()<<"\n"
          <<"--------------";
  ASSERT_EQ(os.str (),f_Briton.reqPersonneFormate ());
}
/**
 *\brief test de la  fonction qui assigne une position qui est permit
 * CAS VALIDE :retour est ceux que on veut
 * cas invalide :position mn'est pas ailier ou centre ou defenseur ou gardien
 */
TEST_F(JoueurValid,asgposition){
  f_Briton.asgposition ("ailier");
  ASSERT_EQ("ailier",f_Briton.reqposition());
}
/**
 *\brief test de la  fonction qui assigne une position qui est permit
 * cas invalide :position mn'est pas ailier ou centre ou defenseur ou gardien
 */
TEST_F(JoueurValid,asgpositioninvalide){
  ASSERT_THROW(f_Briton.asgposition ("ail=ier"),ContratException);
  
}