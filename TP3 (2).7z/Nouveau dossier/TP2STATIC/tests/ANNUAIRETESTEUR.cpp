/**
 * \file Annuairetesteur.cpp
 * \brief teste de la classe Annuaire en testant toute les fonctions 
 * \param[in] string p_nom
 * \param[in] string prenom
 * \param[in] Date de naissance
 * \param[in] string p_telephone
 * \param[in] string position
*/#include "Annuaire.h"
#include<string>
#include"ContratException.h"
#include"validationFormat.h"
#include<sstream>
#include <iostream>
#include"Entraineur.h"
#include<gtest/gtest.h>
#include"Joueur.h"
/**
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :le nom du club non conforme ;
 */

TEST(Annuaire,Constructeur)
{
  hockey::Annuaire Briton("Britonclub");
  ASSERT_EQ("Britonclub",Briton.reqnom ());
}
/**
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :le nom du club non conforme ;
 */
TEST(Annuaire,ConstructeurInvalide)
{
  ASSERT_THROW(hockey::Annuaire Briton(" "),ContratException);
}
class Annuaire1:public ::testing::Test{
public:
  Annuaire1():f_Briton("Britonclub"){};
  hockey::Annuaire f_Briton;
};
/*
 *\brief test sur la fonction reqnom de la classe 
 *  cas valide : m_nomdu club=le nom on veut
 */
TEST_F(Annuaire1,reqnom){
  ASSERT_EQ("Britonclub",f_Briton.reqnom ());
}
/*
 *\brief test sur la fonction ajouterpersonne de la classe 
 *  cas valide : les attribut de la classe sont le meme que la sortie en chaine des charactere
 */
TEST_F(Annuaire1,ajouterpersonne){
  hockey::Joueur Briton("BONNEAU","JEAN",util::Date (1,1,2007),"514-369-9874","centre");
  f_Briton.ajouterPersonne (Briton);
  std::ostringstream os;
  os<<"Club : "<<f_Briton.reqnom()<<"\n"
    <<"---------------------\n"
          <<"Nom                :"<<Briton.reqnom()<<"\n"
          <<"Prenom             :"<<Briton.reqprenom()<<"\n"
          <<"Date de Naissance  :"<<Briton.reqdateNaissance().reqDateFormatee ()<<"\n"
          <<"Telephone          :"<<Briton.reqtelephone ()<<"\n"
          <<"Position           :"<<Briton.reqposition()<<"\n"
          <<"--------------\n";
  ASSERT_EQ(os.str(),f_Briton.reqAnnuaireFormate ());
}/*
 *\brief test sur la fonction reqforamte de la classe 
 *  cas valide : les attribut de la classe sont le meme que la sortie en chaine des charactere
 */
TEST_F(Annuaire1,reqforamte){
  hockey::Entraineur Briton("BONNEAU","JEAN",util::Date (1,1,1970),"514-369-9874","BONJ 7001 0112",'M');
  f_Briton.ajouterPersonne (Briton);
  std::ostringstream os;
  os<<"Club : "<<f_Briton.reqnom()<<"\n"
    <<"---------------------\n"
          <<"Nom                :"<<Briton.reqnom()<<"\n"
          <<"Prenom             :"<<Briton.reqprenom()<<"\n"
          <<"Date de Naissance  :"<<Briton.reqdateNaissance().reqDateFormatee ()<<"\n"
          <<"Telephone          :"<<Briton.reqtelephone ()<<"\n"
          <<"Numero de RAMQ     :"<<Briton.reqnumRAMQ()<<"\n"
          <<"--------------------\n";
  ASSERT_EQ(os.str(),f_Briton.reqAnnuaireFormate ());
}
/*
 *\brief test sur la fonction compteur de la classe 
 *  cas valide : les nombres des classes sont egale a les classes ajoute
 */
TEST_F(Annuaire1,compteur){
  hockey::Entraineur Briton("BONNEAU","JEAN",util::Date (1,1,1970),"514-369-9874","BONJ 7001 0112",'M');
  f_Briton.ajouterPersonne (Briton);
  hockey::Joueur Briton1("BONNEAU","JEAN",util::Date (1,1,2007),"514-369-9874","centre");
  f_Briton.ajouterPersonne (Briton1);
  ASSERT_EQ(2,f_Briton.compteur ());
}
TEST_F(Annuaire1,Constructeurcopie){
  hockey::Annuaire Ann(f_Briton);
  ASSERT_EQ(Ann.reqnom (),f_Briton.reqnom ());
}
TEST_F(Annuaire1,Constructeurdassignation){
  hockey::Annuaire Ann=f_Briton;
  ASSERT_EQ(Ann.reqnom (),f_Briton.reqnom ());
}
TEST_F (Annuaire1,supprime){
  hockey::Entraineur Brit("BONNEAU","JEAN",util::Date (1,1,1970),"514-369-9874","BONJ 7001 0112",'M');
  f_Briton.ajouterPersonne (Brit);
  f_Briton.supprimerPersonne ("BONNEAU","JEAN",util::Date (1,1,1970));
}