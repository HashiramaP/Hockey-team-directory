/*
 * \file Entraineurtesteur.cpp
 * \brief teste l'implementation de la classe Entraineur
 * \param[in] string p_nom
 * \param[in] string prenom
 * \param[in] Date de naissance
 * \param[in] string p_telephone
 * \param[in] string p_numRAMQ
 * \param[in] char p_sexe 
 */

#include <stdlib.h>
#include <iostream>
#include<gtest/gtest.h>
#include"Entraineur.h"
#include"Date.h"
#include"ContratException.h"
#include<cstring>
#include<iostream>
#include<sstream>

/*
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :RAMQ pas conforme s ceux que on veut
 *   cas invalide :sEXE PAS "f" ou"m"
 */

TEST(Entraineur,Constructeur)
{
  util::Date t(1,1,1970);
  hockey::Entraineur Briton("BONNEAU","JEAN",t,"514-369-9874","BONJ 7001 0112",'M');
  ASSERT_EQ("BONNEAU",Briton.reqnom ());
  ASSERT_EQ("JEAN",Briton.reqprenom ());
  ASSERT_EQ(t,Briton.reqdateNaissance ());
  ASSERT_EQ("514-369-9874",Briton.reqtelephone ());
  ASSERT_EQ("BONJ 7001 0112",Briton.reqnumRAMQ ());
  ASSERT_EQ('M',Briton.reqsexe ());
}
/*
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :RAMQ pas conforme s ceux que on veut
 */
TEST(Entraineur,ConstructeurInvalidRAMQ)
{
  util::Date t(1,1,1970);
  ASSERT_THROW( hockey::Entraineur Briton("BONNEAU","JEAN",t,"514-369-9874","BONJ 700 0112",'M'),ContratException);
}
/*
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :Date de naissance pas conforme s ceux que on veut
 */
TEST(Entraineur,ConstructeurInvalidDATEDENAISSANCE){
  util::Date t(1,1,2008);
  ASSERT_THROW( hockey::Entraineur Briton("BONNEAU","JEAN",t,"514-369-9874","BONJ 7001 0112",'M'),ContratException);
}
/*
 *\brief test sur le constructeur  cas valide : creation d'objet
 *   cas invalide :sEXE PAS "f" ou"m"
 */
TEST(Entraineur,ConstructeurInvalidSEXE)
{
  util::Date t(1,1,1970);
  ASSERT_THROW( hockey::Entraineur Briton("BONNEAU","JEAN",t,"514-369-9874","BONJ 7001 0112",'k'),ContratException);
}
class EntraineurValid:public ::testing::Test
{
public :
  EntraineurValid() :f_Briton("BONNEAU","JEAN",util::Date (1,1,1970),"514-369-9874","BONJ 7001 0112",'M'){};
  hockey::Entraineur f_Briton;
};
/*
 *\brief test de la  fonction qui retourne le RAMQ  
 * CAS VALIDE :retour est ceux que on veut
 */
TEST_F(EntraineurValid,reqnumRAMQ)
{
  ASSERT_EQ("BONJ 7001 0112",f_Briton.reqnumRAMQ ());
}
/*
 *\brief test de la  fonction qui retourne le SEXE  
 * CAS VALIDE :retour est ceux que on veut F or M
 */
TEST_F(EntraineurValid,reqsexe)
{
  ASSERT_EQ('M',f_Briton.reqsexe ());
}
/*
 *\brief test de la  fonction qui retourne leS ATTRIBUT de  la classe en un seul chaine de characteres  
 * CAS VALIDE :retour est ceux que on veut
 */
TEST_F(EntraineurValid,reqPersonneFormate)
{
  std::ostringstream os;
  os<<"Nom                :"<<f_Briton.reqnom()<<"\n"<<"Prenom             :"
          <<f_Briton.reqprenom()<<"\n"
          <<"Date de Naissance  :"<<f_Briton.reqdateNaissance().reqDateFormatee ()<<"\n"
          <<"Telephone          :"<<f_Briton.reqtelephone ()<<"\n"
          <<"Numero de RAMQ     :"<<f_Briton.reqnumRAMQ()<<"\n"
          <<"--------------------";
  ASSERT_EQ(os.str (),f_Briton.reqPersonneFormate ());
}