/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PersonneException.h
 * Author: etudiant
 *
 * Created on 7 décembre 2023, 20 h 38
 */

#ifndef PERSONNEEXCEPTION_H
#define PERSONNEEXCEPTION_H
#include <stdexcept>
class PersonneException:public std::runtime_error
{
public:
  PersonneException (const std::string& raison);
};
class PersonneDejaPresenteException:public PersonneException
{
public:
  PersonneDejaPresenteException (const std::string& raison); 
};
class  PersonneAbsenteException:public PersonneException
{
public:
   PersonneAbsenteException(const std::string& raison); 
};

#endif /* PERSONNEEXCEPTION_H */

