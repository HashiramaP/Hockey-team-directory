/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   newmain.cpp
 * Author: etudiant
 *
 * Created on 4 novembre 2023, 18 h 10
 */

#include <cstdlib>
#include"Date.h"
#include"Personne.h"
#include"ContratException.h"
#include"validationFormat.h"
#include<iostream>
#include"Annuaire.h"
#include<string>
#include"Date.h"
#include"Entraineur.h"
#include"Joueur.h"
using namespace std;

/*
 * 
 */
int
main (int argc, char** argv)
{
  hockey::Annuaire Annuaire1("nomduclub");
  hockey::Joueur Briton("BONNEAU","JEAN",util::Date (1,1,2007),"514-369-9874","centre");
   hockey::Entraineur fBriton("BONNEAU","JEAN",util::Date (1,1,1970),"514-369-9874","BONJ 7001 0112",'M');
  Annuaire1.ajouterPersonne (Briton);
  Annuaire1.ajouterPersonne (fBriton);
  cout<<Annuaire1.reqAnnuaireFormate();
  Annuaire1.supprimerPersonne ("BONNEAU","JEAN",util::Date (1,1,2007));
  cout<<Annuaire1.reqAnnuaireFormate();
  

}